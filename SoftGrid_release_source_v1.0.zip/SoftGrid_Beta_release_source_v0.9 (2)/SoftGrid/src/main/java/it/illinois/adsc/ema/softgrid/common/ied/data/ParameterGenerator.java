/* Copyright (C) 2016 Advanced Digital Science Centre

        * This file is part of Soft-Grid.
        * For more information visit https://www.illinois.adsc.com.sg/cybersage/
        *
        * Soft-Grid is free software: you can redistribute it and/or modify
        * it under the terms of the GNU General Public License as published by
        * the Free Software Foundation, either version 3 of the License, or
        * (at your option) any later version.
        *
        * Soft-Grid is distributed in the hope that it will be useful,
        * but WITHOUT ANY WARRANTY; without even the implied warranty of
        * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        * GNU General Public License for more details.
        *
        * You should have received a copy of the GNU General Public License
        * along with Soft-Grid.  If not, see <http://www.gnu.org/licenses/>.

        * @author Prageeth Mahendra Gunathilaka
*/
package it.illinois.adsc.ema.softgrid.common.ied.data;


import it.illinois.adsc.ema.softgrid.common.ied.IedControlAPI;
import javafx.scene.control.SplitPane;
import org.openmuc.openiec61850.internal.mms.asn1.Data;

import java.util.HashMap;
import java.util.StringTokenizer;

/**
 * Created by prageethmahendra on 29/1/2016.
 */
public class ParameterGenerator {
    // Device Name
    String deviceObjectName;
    // key Names
    private String[] keyParameters;
    // Other Variable Names
    private String[] valueParameters;
    // All key and non key Values
    private String[] persistedValues;
    private HashMap<String, String> sclKeyToPWKeyMap = new HashMap<String, String>();
    // API controler COM sc for Power World
    private IedControlAPI controlAPI;

    public ParameterGenerator() {

    }

    public String[][] writePWParameters(String openMucKey, Data dataValue) throws Exception {
        if (openMucKey == null || dataValue == null || !isValid()) {
            throw new Exception("Invalid IDE Prameter State.");
        }
        String mostApplicableKey = "";
        int matchCount = 0;
        boolean found = true;
        String[] keyTokens = openMucKey.split("\\$");
        for (String key : sclKeyToPWKeyMap.keySet()) {
            String[] keyParts = key.split("\\.");
            if (keyTokens.length >= keyParts.length) {
                found = true;
                for (int i = 0; i < keyParts.length; i++) {
                    if (!(keyParts[keyParts.length - i -1].equals(keyTokens[keyTokens.length - i - 1]))) {
                        found = false;
                        break;
                    }
                }
                if (found) {
                    if (matchCount < keyParts.length) {
                        mostApplicableKey = key;
                        matchCount = keyParts.length;
                    }
                }
            }
        }
        String pwKey = sclKeyToPWKeyMap.get(mostApplicableKey);
        if (pwKey != null) {
            int keyIndex = -1;
            for (int i = 0; i < valueParameters.length; i++) {
                if (valueParameters[i] != null) {
                    keyIndex = i + keyParameters.length;
                }
            }
            String[][] paramPack = getParamPack();
            if (keyIndex >= 0) {
                persistedValues[keyIndex] = translatedToPW(pwKey, dataValue);
                // recreate the param pack after translation;
                paramPack = getParamPack();
                String variant = writeDataValues(paramPack);
                if (variant != null && variant.trim().isEmpty()) {
                    return paramPack;
                }
            }
            throw new Exception("Error occured during changeParamegters for Single Element" + deviceObjectName +
                    "\n Parameters : " + paramPack[0].toString() + "\n values " + paramPack[1].toString());
        } else {
            throw new Exception("Invalid IED parameter name : " + openMucKey + " or value : " + dataValue);
        }
    }

    private String translatedToPW(String pwKey, Data dataValue) {
        switch (pwKey) {
            case "LineStatus":
                return dataValue.boolean_.val ? "Open" : "Closed";
            case "SSStatus":
                return dataValue.boolean_.val ? "Open" : "Closed";
        }
        return null;
    }

    public String[] loadDataValues(String[][] paramPack) {
        synchronized (controlAPI) {
            String[] results = controlAPI.getParametersSingleElement(deviceObjectName, paramPack[0], paramPack[1]);
//          return getTokenizedElements(results, paramPack[0].length);
            return results;
        }
    }

    public String writeDataValues(String[][] paramPack) {
        return controlAPI.changeParametersSingleElement(deviceObjectName, paramPack[0], paramPack[1]);
    }

    public String[][] getParamPack() {
        String[] params = new String[keyParameters.length + valueParameters.length];
        int keyIndex = -1;
        String[][] paramPack = new String[2][valueParameters.length];
        for (int i = 0; i < keyParameters.length; i++) {
            params[i] = keyParameters[i];
        }
        for (int i = 0; i < valueParameters.length; i++) {
            params[i + keyParameters.length] = sclKeyToPWKeyMap.get(valueParameters[i]);
        }
        paramPack[0] = params;
        paramPack[1] = persistedValues;
        paramPack[1] = new String[persistedValues.length];
        int i = 0;
        for (String persistedValue : persistedValues) {
            paramPack[1][i]=persistedValue;
            i++;
        }
        return paramPack;
    }

    public static synchronized String[] getTokenizedElements(String str, final int elementCount) {
        String[] elements = new String[elementCount];
        int count = 0;
        str = str.substring(2, str.length() - 1).trim();
        StringTokenizer stringTokenizer = new StringTokenizer(str, " ");
        while (stringTokenizer.hasMoreElements()) {
            if (elements.length == count) {
                break;
            }
            elements[count] = stringTokenizer.nextToken();
            count++;
        }
        return elements;
    }

    public String getDeviceObjectName() {
        return deviceObjectName;
    }

    public void setDeviceObjectName(String deviceObjectName) {
        this.deviceObjectName = deviceObjectName;
    }

    private boolean isValid() {
        return (keyParameters.length + valueParameters.length) == persistedValues.length;
    }

    public String[] getKeyParameters() {
        return keyParameters;
    }

    public void setKeyParameters(String[] keyParameters) {
        this.keyParameters = keyParameters;
    }

    public String[] getValueParameters() {
        return valueParameters;
    }

    public void setValueParameters(String[] valueParameters) {
        this.valueParameters = valueParameters;
    }

    public String[] getPersistedValues() {
        return persistedValues;
    }

    public void setPersistedValues(String[] persistedValues) {
        this.persistedValues = persistedValues;
    }

    public HashMap<String, String> getSclKeyToPWKeyMap() {
        return sclKeyToPWKeyMap;
    }

    public void setSclKeyToPWKeyMap(HashMap<String, String> sclKeyToPWKeyMap) {
        this.sclKeyToPWKeyMap = sclKeyToPWKeyMap;
    }

    public void setControlAPI(IedControlAPI controlAPI) {
        this.controlAPI = controlAPI;
    }
}
