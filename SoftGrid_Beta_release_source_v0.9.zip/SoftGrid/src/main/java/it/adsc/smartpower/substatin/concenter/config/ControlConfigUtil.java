package it.adsc.smartpower.substatin.concenter.config;

/**
 * Created by prageethmahendra on 13/9/2016.
 */
public class ControlConfigUtil {
    private static String CMD_FILE_PATH = "";
}
