package it.adsc.smartpower.substation.monitoring;

/**
 * Created by prageethmahendra on 26/4/2016.
 */
public class SPMonitor {

    public static void main(String[] args) {

    }
}
