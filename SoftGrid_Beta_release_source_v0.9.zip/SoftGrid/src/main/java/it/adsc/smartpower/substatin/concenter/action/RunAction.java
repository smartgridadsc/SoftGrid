package it.adsc.smartpower.substatin.concenter.action;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * Created by prageethmahendra on 29/8/2016.
 */
public class RunAction extends AbstractAction {

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
