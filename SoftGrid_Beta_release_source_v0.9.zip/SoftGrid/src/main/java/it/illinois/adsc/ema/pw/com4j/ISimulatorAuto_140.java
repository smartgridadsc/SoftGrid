package it.illinois.adsc.ema.pw.com4j;

import com4j.*;

@IID("{5BBAE8D5-9F40-4779-AFEB-8FCA43972751}")
public interface ISimulatorAuto_140 extends it.illinois.adsc.ema.pw.com4j.ISimulatorAuto_111 {
  // Methods:
  /**
   * @param fileName Mandatory java.lang.String parameter.
   * @return  Returns a value of type java.lang.Object
   */

  @DISPID(401) //= 0x191. The runtime will prefer the VTID if present
  @VTID(37)
  @ReturnValue(type=NativeType.VARIANT)
  java.lang.Object getCaseHeader(
    java.lang.String fileName);


  // Properties:
}
