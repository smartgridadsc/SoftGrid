package it.illinois.adsc.ema.control;

/**
 * Created by prageethmahendra on 2/3/2016.
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("Abcd");
    }
}
