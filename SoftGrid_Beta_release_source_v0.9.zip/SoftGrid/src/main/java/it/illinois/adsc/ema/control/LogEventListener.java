package it.illinois.adsc.ema.control;

/**
 * Created by prageethmahendra on 5/8/2016.
 */
public interface LogEventListener {
    public void logEvent(String event);
}
