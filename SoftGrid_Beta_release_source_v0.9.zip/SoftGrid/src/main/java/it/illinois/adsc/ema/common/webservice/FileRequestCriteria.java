package it.illinois.adsc.ema.common.webservice;

/**
 * Created by prageethmahendra on 2/10/2016.
 */
public class FileRequestCriteria {
    private String lastFileName;

    public FileRequestCriteria() {
    }

    public String getLastFileName() {
        return lastFileName;
    }

    public void setLastFileName(String lastFileName) {
        this.lastFileName = lastFileName;
    }
}
