package it.illinois.adsc.ema.control.ied;

/**
 * Created by prageethmahendra on 26/4/2016.
 */
public enum IEDType {
    BUS, BRANCH, LOAD, SHUNT, GENERATOR, TRANSFRMER, VIRTUAL;

}
