package it.illinois.adsc.ema.common.webservice;

/**
 * Created by prageethmahendra on 1/9/2016.
 */
public enum ExperimentStatus {
    INIT_STATUS, STARTED, ERROR, FINISHED, STOPED,
    CC_INIT_STATUS, CC_STARTED, CC_ERROR, CC_FINISHED, CC_STOPED
}
