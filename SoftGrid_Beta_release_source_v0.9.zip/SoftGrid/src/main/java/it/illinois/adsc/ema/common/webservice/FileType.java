package it.illinois.adsc.ema.common.webservice;

/**
 * Created by prageethmahendra on 14/9/2016.
 */
public enum FileType {
    ANY, IED_LOG, CASE_FILE, COMMAND_FILE
}
