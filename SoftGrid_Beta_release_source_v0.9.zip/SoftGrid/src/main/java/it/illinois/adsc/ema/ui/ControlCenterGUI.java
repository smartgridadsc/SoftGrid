package it.illinois.adsc.ema.ui;

/**
 * Created by SmartPower on 23/5/2016.
 */
public interface ControlCenterGUI {
    String newASdu(String result);
}
