//package word.counter.web.resources.pojo;
//
//import javax.xml.bind.annotation.XmlRootElement;
//
///**
// * Created by prageeth.g on 29/1/2016.
// */
//@XmlRootElement()
//public class TransferResults {
//    private long maxWord;
//    private long minWord;
//    private long medWord;
//    private long evenMedWord;
//
//    private String maxWordString;
//    private String medWordString;
//    private String evenMedWordString;
//    private String minWordString;
//
//    public TransferResults() {
//    }
//
//    public long getEvenMedWord() {
//        return evenMedWord;
//    }
//
//    public void setEvenMedWord(long evenMedWord) {
//        this.evenMedWord = evenMedWord;
//    }
//
//    public String getEvenMedWordString() {
//        return evenMedWordString;
//    }
//
//    public void setEvenMedWordString(String evenMedWordString) {
//        this.evenMedWordString = evenMedWordString;
//    }
//
//    public long getMaxWord() {
//        return maxWord;
//    }
//
//    public void setMaxWord(long maxWord) {
//        this.maxWord = maxWord;
//    }
//
//    public long getMinWord() {
//        return minWord;
//    }
//
//    public void setMinWord(long minWord) {
//        this.minWord = minWord;
//    }
//
//    public long getMedWord() {
//        return medWord;
//    }
//
//    public void setMedWord(long medWord) {
//        this.medWord = medWord;
//    }
//
//    public String getMaxWordString() {
//        return maxWordString;
//    }
//
//    public void setMaxWordString(String maxWordString) {
//        this.maxWordString = maxWordString;
//    }
//
//    public String getMedWordString() {
//        return medWordString;
//    }
//
//    public void setMedWordString(String medWordString) {
//        this.medWordString = medWordString;
//    }
//
//    public String getMinWordString() {
//        return minWordString;
//    }
//
//    public void setMinWordString(String minWordString) {
//        this.minWordString = minWordString;
//    }
//
//    @Override
//    public String toString() {
//        return "TransferResults{" +
//                "maxWord=" + maxWord +
//                ", minWord=" + minWord +
//                ", medWord=" + medWord +
//                ", evenMedWord=" + evenMedWord +
//                ", maxWordString='" + maxWordString + '\'' +
//                ", medWordString='" + medWordString + '\'' +
//                ", evenMedWordString='" + evenMedWordString + '\'' +
//                ", minWordString='" + minWordString + '\'' +
//                '}';
//    }
//}
