package it.illinois.adsc.ema.control.proxy;

/**
 * Created by SmartPower on 1/6/2016.
 */
public enum ProxyType {
    NORMAL,SECURITY_ENABLED
}
