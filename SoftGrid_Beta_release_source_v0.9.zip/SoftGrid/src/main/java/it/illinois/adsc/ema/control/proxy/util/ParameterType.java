package it.illinois.adsc.ema.control.proxy.util;

/**
 * Created by prageethmahendra on 2/2/2016.
 */
public enum ParameterType {
    BRANCH_LINE_STATUS, FLOAT_VALUE, STRING_VALUE
}
