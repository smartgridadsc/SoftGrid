package it.illinois.adsc.ema.control.proxy.util;

/**
 * Created by prageethmahendra on 2/2/2016.
 */
public enum DeviceType {
    ROOT,CIRCUITE_BREACKER, GENERATOR, TRANSFORMER, SHUNT, BUS, BRANCH, LOAD, MONITOR
}
