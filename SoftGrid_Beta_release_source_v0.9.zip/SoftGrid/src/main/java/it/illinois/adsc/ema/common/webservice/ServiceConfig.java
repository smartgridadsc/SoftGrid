package it.illinois.adsc.ema.common.webservice;

/**
 * Created by prageethmahendra on 31/8/2016.
 */
public class ServiceConfig {
    public static String BASE_URI = "http://localhost:8080/softgrid/";
}
