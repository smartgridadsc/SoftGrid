package it.illinois.adsc.ema.pw;

/**
 * Created by prageethmahendra on 9/6/2016.
 */
public enum PWComType {
    COM4J, JACOB
}
