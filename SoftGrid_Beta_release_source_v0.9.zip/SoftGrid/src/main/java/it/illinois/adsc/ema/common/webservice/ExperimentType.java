package it.illinois.adsc.ema.common.webservice;

/**
 * Created by prageethmahendra on 1/9/2016.
 */
public enum ExperimentType {
    SETUP,INIT,RUN,CHECK, RESET
}
