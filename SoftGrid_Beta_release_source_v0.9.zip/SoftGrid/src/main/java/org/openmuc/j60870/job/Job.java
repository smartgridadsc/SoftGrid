package org.openmuc.j60870.job;

/**
 * Created by prageethmahendra on 18/7/2016.
 */
public interface Job {
    public void execute(MessageContext messageContext);
}
