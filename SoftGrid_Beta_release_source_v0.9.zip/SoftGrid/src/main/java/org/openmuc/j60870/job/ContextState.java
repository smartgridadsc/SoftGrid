package org.openmuc.j60870.job;

/**
 * Created by prageethmahendra on 19/7/2016.
 */
public enum ContextState {
    REQUEST, IGNORE, RESPONSE
}
